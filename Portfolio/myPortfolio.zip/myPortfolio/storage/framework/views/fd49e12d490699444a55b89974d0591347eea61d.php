


<?php $__env->startSection('content'); ?>

  <?php echo $__env->yieldContent('header'); ?>
  <main id="main">

    <section id="work" class="portfolio-mf sect-pt4 route mt-5">
      <div class="container">
        <div class="row">
          <div class="col-sm-12">
            <div class="title-box text-center">
              <h3 class="title-a">
                Portfolio
              </h3>
              <p class="subtitle-a">
                COMING SOON
              </p>
              <div class="line-mf"></div>
            </div>
          </div>
        </div>
        
      </div>
    </section><!-- End Portfolio Section -->

    

  </main><!-- End #main -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /mnt/c/laravel/myPortfolio/resources/views/project.blade.php ENDPATH**/ ?>